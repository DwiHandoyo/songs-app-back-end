npm run start-prod

npm install -g pm2

pm2 start npm --name "notes-api" -- run "start-prod" 
pm2 restart notes-api
pm2 stop notes-api
pm2 start notes-api

ssh -i "notes-api-webserver.pem" database-1.ckj2uawcmcse.ap-southeast-1.rds.amazonaws.com